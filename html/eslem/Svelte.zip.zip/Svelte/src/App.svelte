<script>
	import { text } from "svelte/internal";
	import Tesseract from "tesseract.js";

	import myjson1 from "./testdata/omaskuchen.json";
	import myjson2 from "./testdata/eierdip.json";
	import myjson3 from "./testdata/holder.json";
	import myjson4 from "./testdata/tomatenbutter.json";
	//import myjson5 from "./testdata/zucchini.json";

	//export let title = "Kochrezept Beispiel";
	export let image = "https://via.placeholder.com/400";
	//export let ingredients = ["Zutat 1", "Zutat 2", "Zutat 3"];
	//export let instructions = ["Anweisung 1", "Anweisung 2", "Anweisung 3"];

	//const fs = require("node:fs");

	console.log("mjson1", myjson1);
	console.log("mjson2", myjson2);
	console.log("mjson2", myjson3);
	console.log("mjson2", myjson4);
	//console.log("mjson2", myjson5);

	/*
	readFile(filePath, "utf8", (err, data) => {
		if (err) {
			console.error(err);
			return;
		}

		const jsonObject = JSON.parse(data);
		console.log(jsonObject);
	});
	*/

	/* import { parse } from "svelte/compiler";
	const ast = parse(/testdata/, { filename: "omaskuchen.json" });

	console.log(ast);
	

	const omaoe = {
		Titel: "Omas Lieblingskuchen",
		Zutaten: [
			{
				Name: "Mehl",
				Menge: "30",
				Einheit: "dkg",
			},
			{
				Name: "Vanillezucker",
				Menge: "1",
				Einheit: "Päckchen",
			},
			{
				Name: "Zucker",
				Menge: "200",
				Einheit: "g",
			},
			{
				Name: "Zimt",
				Menge: "0.25",
				Einheit: "TL",
			},
			{
				Name: "Eier",
				Menge: "3",
				Einheit: "Stück",
			},
			{
				Name: "Rosinen",
				Menge: "nach Geschmack",
				Einheit: "",
			},
			{
				Name: "Zitronensaft",
				Menge: "nach Geschmack",
				Einheit: "",
			},
			{
				Name: "Rum",
				Menge: "nach Geschmack",
				Einheit: "",
			},
		],
		Anweisung: [
			"Rosinen in Rum einweichen (1 Handvoll)",
			"Mehl mit Backpulver vermischen, alle anderen Zutaten dazugeben und mit den Rührbesen alles gut rühren.",
			"In eine gefettete Form geben und bei 175 Grad ca. 3/4 Stunde backen.",
			"Mit einer Nadel Probe machen.",
		],
	};

	*/
	const omaString = JSON.stringify(myjson1);

	console.log(omaString);

	const omapars = JSON.parse(omaString);
	console.log(omapars);

	// Reaktive Variablen erstellen
	let title1;
	$: title1 = omapars.Titel;

	let jsonFiles = [
		{ name: "Omakuchen", data: myjson1 },
		{ name: "Eierdip", data: myjson2 },
		{ name: "Holder", data: myjson3 },
		{ name: "Tomatenbutter", data: myjson4 },
		//{ name: "Zucchini", data: myjson5 },
	];

	let selectedJson = jsonFiles[0].data;

	// Reaktive Variablen für Formularfelder
	let title = "";
	let ingredients = [];
	let instructions = [];

	// Funktion zum Laden der JSON-Daten in die Formularfelder
	function loadJsonData(json) {
		title = json.Titel;
		ingredients = json.Zutaten.map(
			(zutat) => `${zutat.Menge} ${zutat.Einheit} ${zutat.Name}`,
		);
		instructions = json.Anweisung;
	}

	// Initiale Daten laden
	loadJsonData(selectedJson);

	// Funktion zum Speichern der Daten im lokalen Speicher
	function saveToLocalStorage() {
		const data = {
			Titel: title,
			Zutaten: ingredients,
			Anweisung: instructions,
		};
		localStorage.setItem("rezept", JSON.stringify(data));
		alert("Rezept gespeichert!");
	}
</script>

<main>
	<div class="container">
		<h1>{title}</h1>
		<label for="json-select">Wähle ein Rezept:</label>
		<select
			id="json-select"
			bind:value={selectedJson}
			on:change={() => loadJsonData(selectedJson)}
		>
			{#each jsonFiles as file}
				<option value={file.data}>{file.name}</option>
			{/each}
		</select>
		<img src={image} alt="Rezeptbild" />
		<h2>Zutaten:</h2>
		<ul>
			<ul>
				{#each ingredients as ingredient}
					<li>{ingredient}</li>
				{/each}
			</ul>
		</ul>
		<h2>Anweisung:</h2>
		<div>
			<ul>
				{#each instructions as instruction}
					<li>{instruction}</li>
				{/each}
			</ul>
		</div>
		<button on:click={saveToLocalStorage}>Speichern</button>
	</div>
</main>

<style>
	.container {
		max-width: 800px;
		margin: 20px auto;
		padding: 20px;
		border: 1px solid #ccc;
		border-radius: 5px;
		background-color: #f9f9f9;
	}
	h1 {
		text-align: center;
	}
	img {
		max-width: 50%;
		height: auto;
		display: block;
		float: right;
		margin: 20px auto;
	}
	ul {
		list-style-type: none;
		padding: 0;
	}
	li {
		margin-bottom: 10px;
	}
</style>
